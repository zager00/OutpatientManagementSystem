<?php

/*
 * All database connection variables
 */

define('DB_USER', "group1"); // db user
define('DB_PASSWORD', "group1"); // db password (mention your db password here)
define('DB_DATABASE', "healthit"); // database name
define('DB_SERVER', "hit4.nimbus.cip.gatech.edu:3306"); // db server
?>