<?php

	echo 'Test: '.$_GET['test'].'<br/>';
	
?>